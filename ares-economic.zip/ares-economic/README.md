# Ares Economic

**Calendrier économique professionnel orienté Forex & Gold**

Site simple, dark mode, avec analyses mixtes (modèle + sources), probabilités Buy/Sell et niveaux de prix.

---

## Fonctionnalités

- **Calendrier économique** (Forex + Gold)
- Filtres : Impact / Devise / Gold related / Période
- **Gold Focus** : événements les plus influents sur l’or + corrélation DXY
- Vue **Cette semaine**
- Mini résumé journalier
- **Analyse mixte** pour les événements importants :
  - Texte d’analyse
  - Bias (Buy / Sell)
  - Probabilité Buy Gold / Sell Gold (barres)
  - Niveaux de prix (Support / Résistance / Zone)
  - Source
- Heure de Paris
- Design professional dark mode
- 100% responsive (mobile-friendly)
- Fiteny : **Français**

---

## Structure du projet

```
ares-economic/
├── index.html      # Page principale
├── style.css       # Design dark professionnel
├── script.js       # Logique + données d’exemple
└── README.md
```

---

## Installation / Utilisation

### Option 1 — Simple (recommandé pour test)
1. Télécharge ou clone le repo
2. Ouvre `index.html` directement dans ton navigateur

### Option 2 — Live Server (meilleur)
```bash
# Avec VS Code : installe l’extension "Live Server" puis clique droit → Open with Live Server
# Ou avec Python :
python -m http.server 8000
```
Puis ouvre `http://localhost:8000`

### Option 3 — GitHub Pages
1. Push le dossier sur un repo GitHub
2. Settings → Pages → Deploy from branch `main`
3. Le site sera en ligne

---

## Données

Les données actuelles sont **des exemples réalistes** (semaine du 1-12 septembre 2026) pour démonstration.

Pour un usage réel tu peux :
- Connecter une API de calendrier économique (payante la plupart du temps)
- Ou mettre à jour manuellement le tableau `EVENTS` dans `script.js`

Sources style utilisées dans les analyses : BLS, Fed, ECB, réaction marché, corrélation DXY/Gold.

---

## Personnalisation rapide

| Élément              | Fichier     | Où modifier                          |
|----------------------|-------------|--------------------------------------|
| Nom du site          | index.html  | Logo + title                         |
| Couleurs             | style.css   | Variables `:root`                    |
| Événements + Analyse | script.js   | Tableau `EVENTS`                     |
| Timezone             | script.js   | Fonction `updateClock()`             |

---

## Avertissement

Les analyses et probabilités sont fournies à titre **indicatif et éducatif**.  
Ce n’est **pas un conseil en investissement**.  
Trade toujours avec un money management strict.

---

**Ares Economic** — Forex & Gold Calendar
