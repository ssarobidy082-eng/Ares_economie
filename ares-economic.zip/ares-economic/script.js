/* ===== Ares Economic — Main Script ===== */

// Sample data (realistic structure for Sep 2026 week)
// In production: replace with API (Forex Factory style / Investing / paid calendar API)
const EVENTS = [
  {
    id: 1,
    date: "2026-09-04",
    time: "14:30",
    currency: "USD",
    event: "Initial Jobless Claims",
    impact: "medium",
    actual: "218K",
    forecast: "225K",
    previous: "231K",
    goldRelated: true,
    analysis: {
      text: "Demandes d'allocations chômage inférieures aux attentes. Marché de l'emploi reste résilient → soutien modéré au dollar.",
      bias: "Buy USD / Sell Gold",
      buyProb: 38,
      sellProb: 62,
      levels: { support: "2 348 $", resistance: "2 375 $", zone: "2 355 – 2 362 $" },
      source: "Department of Labor + réaction DXY"
    }
  },
  {
    id: 2,
    date: "2026-09-04",
    time: "14:30",
    currency: "USD",
    event: "Continuing Jobless Claims",
    impact: "low",
    actual: "1.86M",
    forecast: "1.87M",
    previous: "1.88M",
    goldRelated: false,
    analysis: null
  },
  {
    id: 3,
    date: "2026-09-05",
    time: "14:30",
    currency: "USD",
    event: "Non-Farm Payrolls (NFP)",
    impact: "high",
    actual: "178K",
    forecast: "165K",
    previous: "142K",
    goldRelated: true,
    analysis: {
      text: "NFP nettement au-dessus des attentes (178K vs 165K). Dollar renforcé, rendement des Treasuries en hausse. Pression baissière claire sur l'or à court terme.",
      bias: "Sell Gold / Buy USD",
      buyProb: 28,
      sellProb: 72,
      levels: { support: "2 340 $", resistance: "2 368 $", zone: "2 348 – 2 355 $" },
      source: "BLS + réaction marché + corrélation DXY"
    }
  },
  {
    id: 4,
    date: "2026-09-05",
    time: "14:30",
    currency: "USD",
    event: "Unemployment Rate",
    impact: "high",
    actual: "4.1%",
    forecast: "4.2%",
    previous: "4.2%",
    goldRelated: true,
    analysis: {
      text: "Taux de chômage en baisse à 4.1%. Confirmation d'un marché du travail solide. Renforce le scénario hawkish pour la Fed.",
      bias: "Sell Gold / Buy USD",
      buyProb: 30,
      sellProb: 70,
      levels: { support: "2 340 $", resistance: "2 368 $", zone: "2 348 – 2 355 $" },
      source: "BLS + Fed Watch"
    }
  },
  {
    id: 5,
    date: "2026-09-05",
    time: "14:30",
    currency: "USD",
    event: "Average Hourly Earnings (MoM)",
    impact: "medium",
    actual: "0.3%",
    forecast: "0.3%",
    previous: "0.2%",
    goldRelated: true,
    analysis: {
      text: "Salaires en ligne avec les attentes. Pas de surprise inflationniste majeure côté salaires.",
      bias: "Neutre court terme",
      buyProb: 48,
      sellProb: 52,
      levels: { support: "2 348 $", resistance: "2 375 $", zone: "2 355 – 2 362 $" },
      source: "BLS"
    }
  },
  {
    id: 6,
    date: "2026-09-08",
    time: "09:00",
    currency: "EUR",
    event: "German Industrial Production (MoM)",
    impact: "medium",
    actual: null,
    forecast: "0.4%",
    previous: "-1.1%",
    goldRelated: false,
    analysis: null
  },
  {
    id: 7,
    date: "2026-09-08",
    time: "11:00",
    currency: "EUR",
    event: "Eurozone GDP (QoQ) Final",
    impact: "medium",
    actual: null,
    forecast: "0.2%",
    previous: "0.2%",
    goldRelated: false,
    analysis: null
  },
  {
    id: 8,
    date: "2026-09-09",
    time: "15:00",
    currency: "USD",
    event: "JOLTS Job Openings",
    impact: "medium",
    actual: null,
    forecast: "7.55M",
    previous: "7.67M",
    goldRelated: true,
    analysis: {
      text: "Ouvertures de postes attendues en légère baisse. Surveiller si le ralentissement se confirme.",
      bias: "Légèrement Buy Gold si faible",
      buyProb: 55,
      sellProb: 45,
      levels: { support: "2 345 $", resistance: "2 380 $", zone: "2 355 – 2 365 $" },
      source: "BLS (prévision)"
    }
  },
  {
    id: 9,
    date: "2026-09-10",
    time: "14:30",
    currency: "USD",
    event: "CPI (MoM)",
    impact: "high",
    actual: null,
    forecast: "0.2%",
    previous: "0.2%",
    goldRelated: true,
    analysis: {
      text: "Inflation US très attendue. Un chiffre supérieur aux attentes renforcerait le dollar et pèserait sur l'or. Un soft CPI favoriserait l'or.",
      bias: "Dépendant du chiffre (High volatility)",
      buyProb: 50,
      sellProb: 50,
      levels: { support: "2 335 $", resistance: "2 390 $", zone: "2 350 – 2 370 $" },
      source: "Consensus marché + historique réaction Gold"
    }
  },
  {
    id: 10,
    date: "2026-09-10",
    time: "14:30",
    currency: "USD",
    event: "CPI (YoY)",
    impact: "high",
    actual: null,
    forecast: "2.9%",
    previous: "2.9%",
    goldRelated: true,
    analysis: {
      text: "CPI annuel stable attendu à 2.9%. Tout écart significatif déclenchera de la volatilité sur USD et Gold.",
      bias: "Watch event — volatilité élevée",
      buyProb: 50,
      sellProb: 50,
      levels: { support: "2 335 $", resistance: "2 390 $", zone: "2 350 – 2 370 $" },
      source: "Consensus + corrélation historique"
    }
  },
  {
    id: 11,
    date: "2026-09-10",
    time: "20:00",
    currency: "USD",
    event: "FOMC Member Speech",
    impact: "medium",
    actual: null,
    forecast: null,
    previous: null,
    goldRelated: true,
    analysis: {
      text: "Discours de membre FOMC. Ton hawkish = USD up / Gold down. Ton dovish = inverse.",
      bias: "Selon le ton",
      buyProb: 50,
      sellProb: 50,
      levels: { support: "2 340 $", resistance: "2 385 $", zone: "2 355 – 2 370 $" },
      source: "Fed speakers calendar"
    }
  },
  {
    id: 12,
    date: "2026-09-11",
    time: "14:30",
    currency: "USD",
    event: "PPI (MoM)",
    impact: "medium",
    actual: null,
    forecast: "0.1%",
    previous: "0.0%",
    goldRelated: true,
    analysis: {
      text: "Prix à la production. Souvent un leading indicator de l'inflation CPI. Surveiller les surprises.",
      bias: "Neutre à légèrement Sell Gold si chaud",
      buyProb: 45,
      sellProb: 55,
      levels: { support: "2 345 $", resistance: "2 380 $", zone: "2 355 – 2 365 $" },
      source: "BLS (prévision)"
    }
  },
  {
    id: 13,
    date: "2026-09-12",
    time: "14:30",
    currency: "USD",
    event: "Retail Sales (MoM)",
    impact: "high",
    actual: null,
    forecast: "0.3%",
    previous: "0.4%",
    goldRelated: true,
    analysis: {
      text: "Ventes au détail = baromètre de la consommation US. Fort = USD bullish / Gold sous pression.",
      bias: "Sell Gold si > forecast",
      buyProb: 40,
      sellProb: 60,
      levels: { support: "2 340 $", resistance: "2 375 $", zone: "2 350 – 2 362 $" },
      source: "Census Bureau + historique"
    }
  },
  {
    id: 14,
    date: "2026-09-03",
    time: "15:45",
    currency: "EUR",
    event: "ECB Interest Rate Decision",
    impact: "high",
    actual: "3.65%",
    forecast: "3.65%",
    previous: "3.65%",
    goldRelated: false,
    analysis: {
      text: "BCE maintient ses taux. Focus sur le discours de Lagarde et les projections. Impact limité direct sur Gold, plus sur EURUSD.",
      bias: "Neutre Gold / Watch EUR",
      buyProb: 48,
      sellProb: 52,
      levels: { support: "2 348 $", resistance: "2 375 $", zone: "2 355 – 2 365 $" },
      source: "ECB + réaction EURUSD"
    }
  },
  {
    id: 15,
    date: "2026-09-02",
    time: "11:00",
    currency: "GBP",
    event: "UK Manufacturing PMI",
    impact: "medium",
    actual: "51.2",
    forecast: "51.0",
    previous: "50.8",
    goldRelated: false,
    analysis: null
  }
];

// ===== Utilities =====
function parseDate(d) {
  return new Date(d + "T12:00:00");
}

function formatDateFR(dateStr) {
  const d = parseDate(dateStr);
  const days = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
  const months = ["jan", "fév", "mar", "avr", "mai", "juin", "juil", "aoû", "sep", "oct", "nov", "déc"];
  return `${days[d.getDay()]} ${d.getDate()} ${months[d.getMonth()]}`;
}

function getTodayStr() {
  // Fixed to simulation date for demo consistency (4 Sep 2026)
  return "2026-09-04";
}

function isThisWeek(dateStr) {
  // Week of 1-7 Sep 2026 for demo
  const d = parseDate(dateStr);
  const start = parseDate("2026-09-01");
  const end = parseDate("2026-09-07");
  return d >= start && d <= end;
}

function isNextWeek(dateStr) {
  const d = parseDate(dateStr);
  const start = parseDate("2026-09-08");
  const end = parseDate("2026-09-14");
  return d >= start && d <= end;
}

function compareValue(actual, forecast) {
  if (actual === null || forecast === null) return "neutral";
  // Simple heuristic: try to parse numbers
  const a = parseFloat(String(actual).replace(/[^\d.-]/g, ""));
  const f = parseFloat(String(forecast).replace(/[^\d.-]/g, ""));
  if (isNaN(a) || isNaN(f)) return "neutral";
  if (a > f) return "better";
  if (a < f) return "worse";
  return "neutral";
}

// ===== Clock (Paris time) =====
function updateClock() {
  const now = new Date();
  // Simulate Paris time display
  const options = { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Paris" };
  const timeStr = now.toLocaleTimeString("fr-FR", options);
  document.getElementById("clock").textContent = timeStr;
}

// ===== Filtering =====
function getFilteredEvents() {
  const impact = document.getElementById("filterImpact").value;
  const currency = document.getElementById("filterCurrency").value;
  const goldOnly = document.getElementById("filterGold").checked;
  const period = document.getElementById("filterPeriod").value;

  return EVENTS.filter(e => {
    if (impact === "high" && e.impact !== "high") return false;
    if (impact === "medium" && e.impact === "low") return false;
    if (currency !== "all" && e.currency !== currency) return false;
    if (goldOnly && !e.goldRelated) return false;
    if (period === "today" && e.date !== getTodayStr()) return false;
    if (period === "week" && !isThisWeek(e.date)) return false;
    if (period === "next" && !isNextWeek(e.date)) return false;
    return true;
  }).sort((a, b) => {
    const da = a.date + a.time;
    const db = b.date + b.time;
    return da.localeCompare(db);
  });
}

// ===== Render Table Row =====
function createRow(e) {
  const tr = document.createElement("tr");
  const actualClass = e.actual ? `value-${compareValue(e.actual, e.forecast)}` : "value-neutral";

  tr.innerHTML = `
    <td class="date-cell">
      <div class="date-day">${formatDateFR(e.date)}</div>
      <div class="date-time">${e.time} (Paris)</div>
    </td>
    <td><span class="currency-badge">${e.currency}</span></td>
    <td>
      <span class="event-name">${e.event}</span>
      ${e.goldRelated ? '<span class="event-gold-tag">Gold</span>' : ''}
    </td>
    <td>
      <span class="impact-badge ${e.impact}">
        <span class="impact-dot"></span>
        ${e.impact}
      </span>
    </td>
    <td class="value-cell ${actualClass}">${e.actual ?? "—"}</td>
    <td class="value-cell value-neutral">${e.forecast ?? "—"}</td>
    <td class="value-cell value-neutral">${e.previous ?? "—"}</td>
  `;
  return tr;
}

// ===== Render Analysis Card =====
function createAnalysisCard(e) {
  if (!e.analysis) return null;
  const a = e.analysis;
  const card = document.createElement("div");
  card.className = `analysis-card ${e.impact === "high" ? "high-impact" : ""}`;

  const biasClass = a.bias.toLowerCase().includes("buy gold") ? "buy" :
                    a.bias.toLowerCase().includes("sell gold") ? "sell" : "";

  card.innerHTML = `
    <div class="analysis-header">
      <div>
        <div class="analysis-title">${e.event}</div>
        <div class="analysis-meta">${formatDateFR(e.date)} • ${e.time} • ${e.currency} • Impact ${e.impact.toUpperCase()}</div>
      </div>
    </div>
    <div class="analysis-body">${a.text}</div>
    <div class="analysis-bias">
      <div class="bias-item">
        <div class="bias-label">Bias</div>
        <div class="bias-value ${biasClass}">${a.bias}</div>
      </div>
    </div>
    <div class="prob-bars">
      <div class="prob-row">
        <span class="prob-label buy">Buy Gold</span>
        <div class="prob-track"><div class="prob-fill buy" style="width:${a.buyProb}%"></div></div>
        <span class="prob-pct">${a.buyProb}%</span>
      </div>
      <div class="prob-row">
        <span class="prob-label sell">Sell Gold</span>
        <div class="prob-track"><div class="prob-fill sell" style="width:${a.sellProb}%"></div></div>
        <span class="prob-pct">${a.sellProb}%</span>
      </div>
    </div>
    <div class="levels">
      <div class="level-item"><span>Support</span><strong>${a.levels.support}</strong></div>
      <div class="level-item"><span>Résistance</span><strong>${a.levels.resistance}</strong></div>
      <div class="level-item"><span>Zone</span><strong>${a.levels.zone}</strong></div>
    </div>
    <div class="analysis-source">Source : ${a.source}</div>
  `;
  return card;
}

// ===== Render Views =====
function renderCalendar() {
  const body = document.getElementById("calendarBody");
  const analysisBox = document.getElementById("analysisContainer");
  body.innerHTML = "";
  analysisBox.innerHTML = "";

  const events = getFilteredEvents();
  events.forEach(e => body.appendChild(createRow(e)));

  // Only show analysis for high & medium with analysis
  events.filter(e => e.analysis && (e.impact === "high" || e.impact === "medium"))
        .forEach(e => {
          const card = createAnalysisCard(e);
          if (card) analysisBox.appendChild(card);
        });
}

function renderGold() {
  const body = document.getElementById("goldBody");
  const analysisBox = document.getElementById("goldAnalysisContainer");
  body.innerHTML = "";
  analysisBox.innerHTML = "";

  const events = EVENTS.filter(e => e.goldRelated).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  events.forEach(e => body.appendChild(createRow(e)));

  events.filter(e => e.analysis).forEach(e => {
    const card = createAnalysisCard(e);
    if (card) analysisBox.appendChild(card);
  });
}

function renderWeek() {
  const body = document.getElementById("weekBody");
  const analysisBox = document.getElementById("weekAnalysisContainer");
  body.innerHTML = "";
  analysisBox.innerHTML = "";

  document.getElementById("weekRange").textContent = "1 – 7 septembre 2026";

  const events = EVENTS.filter(e => isThisWeek(e.date)).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  events.forEach(e => body.appendChild(createRow(e)));

  events.filter(e => e.analysis).forEach(e => {
    const card = createAnalysisCard(e);
    if (card) analysisBox.appendChild(card);
  });
}

function updateSummary() {
  const todayEvents = EVENTS.filter(e => e.date === getTodayStr());
  const high = todayEvents.filter(e => e.impact === "high").length;
  const med = todayEvents.filter(e => e.impact === "medium").length;
  const gold = todayEvents.filter(e => e.goldRelated).length;

  let text = "";
  if (todayEvents.length === 0) {
    text = "Aucun événement majeur aujourd'hui.";
  } else {
    text = `${todayEvents.length} événement(s) — ${high} High Impact`;
    if (gold > 0) text += ` — ${gold} lié(s) à l'or`;
    if (high > 0) text += ". Focus USD & Gold.";
  }
  document.getElementById("summaryText").textContent = text;
}

// ===== Navigation =====
function switchView(viewName) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));

  document.getElementById(`view-${viewName}`).classList.add("active");
  document.querySelector(`.nav-btn[data-view="${viewName}"]`).classList.add("active");

  if (viewName === "calendar") renderCalendar();
  if (viewName === "gold") renderGold();
  if (viewName === "week") renderWeek();
}

// ===== Init =====
document.addEventListener("DOMContentLoaded", () => {
  updateClock();
  setInterval(updateClock, 30000);
  updateSummary();

  // Filters
  ["filterImpact", "filterCurrency", "filterGold", "filterPeriod"].forEach(id => {
    document.getElementById(id).addEventListener("change", () => {
      if (document.getElementById("view-calendar").classList.contains("active")) {
        renderCalendar();
      }
    });
  });

  // Nav
  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });

  // Initial render
  renderCalendar();
});
